document.getElementById('enquiryForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const fullName = document.getElementById('fullName').value.trim();
    const email = document.getElementById('email').value.trim();
    const eventSelected = document.getElementById('event').value;
    const message = document.getElementById('message').value.trim();

    if (!fullName || !email || !eventSelected || !message) {
        alert('PLEASE ENTER THE VALUES!');
        return;
    }

    const popupContent = `
        <h2>Congratulations!!!</h2>
        <p><strong>Name:</strong> ${fullName}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Interested Event:</strong> ${eventSelected}</p>
        <p><strong>Detailed Enquiry:</strong> ${message}</p>
    `;

    const popupWindow = window.open('', '_blank', 'width=400,height=400');
    popupWindow.document.write(`
        <html>
        <head>
            <title>Form Submission</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                h2 { color: #333; }
                p { margin: 10px 0; }
            </style>
        </head>
        <body>
            ${popupContent}
        </body>
        </html>
    `);
    popupWindow.document.close();
});
